<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
</head>
<body>
    <h2>Order Form</h2>
    <form action="handle_contact.php" method="POST">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br><br>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>
        
        <label for="phone">Phone Number:</label>
        <input type="text" id="phone" name="phone" required><br><br>
        
        <label for="address">Address:</label>
        <input type="text" id="address" name="address" required><br><br>
        
        <label for="product_name">Product Name:</label>
        <select id="product_name" name="product_name" required>
            <option value="Product A">Product A</option>
            <option value="Product B">Product B</option>
            <option value="Product C">Product C</option>
        </select><br><br>
        
        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" name="quantity" required><br><br>
        
        <label for="price">Price per Unit:</label>
        <input type="number" step="0.01" id="price" name="price" required><br><br>
        
        <input type="submit" value="Submit">
    </form>
    
    <h2>Search, Edit, Delete Contacts</h2>
    <form action="search_contact.php" method="GET">
        <label for="search">Search by Name:</label>
        <input type="text" id="search" name="search" required>
        <input type="submit" value="Search">
    </form>
</body>
</html>
