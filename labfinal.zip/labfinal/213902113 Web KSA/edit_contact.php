<?php
include('connect.php');

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $mysqli->prepare("SELECT * FROM contacts WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        ?>
        <form action="update_contact.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>" required><br><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $row['email']; ?>" required><br><br>

            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" value="<?php echo $row['phone']; ?>" required><br><br>

            <label for="address">Address:</label>
            <input type="text" id="address" name="address" value="<?php echo $row['address']; ?>" required><br><br>

            <label for="product_name">Product Name:</label>
            <select id="product_name" name="product_name" required>
                <option value="Product A" <?php if ($row['product_name'] == 'Product A') echo 'selected'; ?>>Product A</option>
                <option value="Product B" <?php if ($row['product_name'] == 'Product B') echo 'selected'; ?>>Product B</option>
                <option value="Product C" <?php if ($row['product_name'] == 'Product C') echo 'selected'; ?>>Product C</option>
            </select><br><br>

            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" value="<?php echo $row['quantity']; ?>" required><br><br>

            <label for="price">Price per Unit:</label>
            <input type="number" step="0.01" id="price" name="price" value="<?php echo $row['price']; ?>" required><br><br>

            <input type="submit" value="Update">
        </form>
        <?php
    } else {
        echo "Record not found";
    }

    $stmt->close();
}

$mysqli->close();
?>
