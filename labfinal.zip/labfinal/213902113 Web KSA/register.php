<?php
include('connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $age = $_POST['age'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];

    $stmt = $mysqli->prepare("INSERT INTO users (username, password, age, address, phone, email) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssisss", $username, $password, $age, $address, $phone, $email);

    if ($stmt->execute()) {
        // Registration successful, redirect to login.html
        header("Location: login.html");
        exit(); // Ensure that subsequent code is not executed after redirection
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$mysqli->close();
?>
